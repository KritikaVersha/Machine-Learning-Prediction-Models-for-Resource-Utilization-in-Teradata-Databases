#!/usr/bin/env python
from xml.etree.ElementTree import XML, fromstring, tostring
import re,csv,datetime
import numpy as np
from sklearn.svm import SVR
from sklearn import svm
import matplotlib.pyplot as plt
from sklearn import linear_model
from dateutil import parser
from sklearn import linear_model
from sklearn.linear_model import Ridge
from sklearn.svm import LinearSVC
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import operator as o
from sklearn.metrics import accuracy_score
import sys

# Convert the CSV to XML
def extractxml(filename):
    
    with open(filename, "rb") as outfile:
        rows = []
        input_params = []
        output_params = []
        for i in outfile.readlines():
            if 'XMLTextInfo' not in i and 'END QUERY LOGGING':
                rows.append(i.split('","'))        
    
    skip_line = False
    for single_row in range(len(rows)):

	# If this line was processed as part of the previous one, skip it
	if skip_line == True:
		skip_line = False
		continue

	currline = rows[single_row][-1][:-2]

	# If the XML is all on one line
	if '<?xml' in currline and '</QryPlanXML>' in currline:
	    completexml = currline.lower()
	# If the XML is on two lines
	else:
		nextline = rows[single_row + 1][-1][:-2]
		# If the first part is on the first line
		if '<?xml' in currline:	
			completexml = currline.lower() + nextline.lower() 
		# If the first part is on the second line
		else:
			completexml = nextline.lower() + ' ' + currline.lower() 
			completexml2 = nextline.lower() + currline.lower()
		skip_line = True
	
	try:
		xmlstring = fromstring(completexml.encode('utf-16-be')) 
	except:
		xmlstring = fromstring(completexml2.encode('utf-16-be')) 
	parsed_values = parsetree(xmltree = xmlstring)
	parsed_row = xmldata(xmlvalue = parsed_values)
	input_params.append(parsed_row)
	
	outputs = []
	# Append the response time
	outputs.append(str(((parser.parse((rows[single_row])[8]))-(parser.parse((rows[single_row])[6])))).split(":")[-1])
	# Append the total IO count
	outputs.append(int(((rows[single_row])[10]).replace(',', '')))
	# Append the AMP CPU time
	outputs.append(float(((rows[single_row])[11]).replace('','')))
	# Append the spool usage
	outputs.append(int(((rows[single_row])[21]).replace(',','')))
	output_params.append(outputs)

    input_dataset = np.array(input_params, np.float)
    output_dataset = np.array(output_params, np.float)
    return [input_dataset, output_dataset]
        
# Parse the XML
def parsetree(xmltree):
    d = {}
    for i in xmltree.getiterator():
        for key,value in (i.attrib).items():
            d.setdefault(key, [])
            if key not in d:
                d[key] = value
            else:
                d[key].append(value)
    return d

# Obtain the features from the XML
def xmldata(xmlvalue):
    dataset = []
    input_params = ['ampcpurundelay', 'iokb', 'ampcputime', 'minampio', 'maxampcpurundelay', 'parsercputime',
	 	'maxampotherwaittime', 'peotherwaittime', 'reqphysiokb', 'cputime', 'ampotherwaittime', 
		'pecpurundelay', 'parsercpukerneltime', 'indextype', 'maxampcputime', 'peiowaittime']
    for param in input_params:
        if param != 'indextype':
            if xmlvalue.get(param) is not None:
                dataset.append(sum([float(x) for x in xmlvalue.get(param)]))
            else:
                dataset.append('0')
    return dataset   

# Show the predictions for all four models
def showPredictions(trainfile, testfile):
    [training_inputs, training_outputs]=extractxml(trainfile)
    [test_inputs, test_outputs]=extractxml(testfile)
    showLeastSquare(training_inputs, training_outputs, test_inputs, test_outputs)
    showLeastSquareWithNormalization(training_inputs, training_outputs, test_inputs, test_outputs)
    showRidge(training_inputs, training_outputs, test_inputs, test_outputs)
    showLasso(training_inputs, training_outputs, test_inputs, test_outputs)
    
# Print a simple header
def printHeader(header):
    print "********* " + header + " *********"

# Calculate the percentage errors and print them
def printResults(pred, actual):
    predictions = pred[0].tolist()
    actual_vals = actual[0]
    if actual_vals[2] == 0.:
	actual_vals[2] = 0.0001
    resp_time = "%.4f" % (abs((actual_vals[0] - abs(predictions[0])) / actual_vals[0]) * 100)
    io_count = "%.4f" % (abs((actual_vals[1] - abs(predictions[1])) / actual_vals[1]) * 100)
    cpu_time = "%.4f" % (abs((actual_vals[2] - abs(predictions[2])) / actual_vals[2]) * 100)
    print "Response time error percentage: " + resp_time
    print "Total IO count error percentage: " + io_count
    print "AMP CPU time error percentage: " + cpu_time
    print '\n'

# Print the Least Square regression
def showLeastSquare(training_inputs, training_outputs, test_inputs, test_outputs):
    printHeader('Least Square Regression Without Normalization and Regularization')  
    clf = linear_model.LinearRegression(copy_X=True, fit_intercept=True)
    clf.fit(training_inputs, training_outputs)
    pred = clf.predict(test_inputs)
    printResults(pred, test_outputs)
   
# Print the Least Square (with normalization) regression
def showLeastSquareWithNormalization(training_inputs, training_outputs, test_inputs, test_outputs):
    printHeader('Least Square Regression With Normalization')
    clf = linear_model.LinearRegression(copy_X=True, fit_intercept=True, normalize=True)
    clf.fit(training_inputs, training_outputs)
    pred = clf.predict(test_inputs)
    printResults(pred, test_outputs)

# Print the Ridge regression
def showRidge(training_inputs, training_outputs, test_inputs, test_outputs):
    printHeader('Ridge Regression')
    clf = Ridge(alpha=1.0)
    clf.fit(training_inputs, training_outputs)
    pred = clf.predict(test_inputs)
    printResults(pred, test_outputs)
    
# Print the LASSO regression
def showLasso(training_inputs, training_outputs, test_inputs, test_outputs):
    printHeader('LASSO Regression')
    clf = linear_model.Lasso(alpha=0.1, copy_X=True, fit_intercept=True, max_iter=1000, 
			normalize=False, positive=False, precompute='auto', tol=0.0001, warm_start=False)
    clf.fit(training_inputs, training_outputs)
    pred = clf.predict(test_inputs)
    printResults(pred, test_outputs)
