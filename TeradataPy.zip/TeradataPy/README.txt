*******************************************************************************
** Vishal Joshi and Kritika Versha
** 10 December 2014
** EECS 584: Advanced Database Systems
** TeradataPy: a Python tool for predicting query resource utilization
*******************************************************************************

*******************************************************************************
** Folder contents
*******************************************************************************
1. TeradataPy.py: This is the top-level program that is run without any
input arguments. The program first asks the user for the Teradata server,
login credentials, the database name for the database which holds the target
dataset, and the directory for the training set. The training set directory
must be contained within this folder. It must only contain files of the form
query<num>.sql where n goes from 0 to n - 1 for n training set queries. The
program will use the bash scripts to autogenerate BTEQ scripts which run the
training set queries. After the queries are done running and the log files
have been extracted, the user is prompted to enter the filepath of the query
they wish to analyze. Again, the test query must be contained within this 
folder. The user can enter QUIT to exit the program.

2. TeradataML.py: This file contains the code for extracting the XML 
corresponding to the query plan from the Teradata CSV output files as well
as the regression code. It makes heavy use of the Python numpy and sklearn
libraries. The Anaconda package is the recommended download for obtaining
all of these libraries.

3. process-training-set.sh: This is the bash script that executes all of
the queries contained within the training set directory. It also extracts
the features and output parameters and stores them in dbqlog-dump.csv. Please
note that TeradataPy.py will remove this CSV file when execution completes.

4. process-test-query.sh: This is the bash script that executes the test
query specified by the user. It extracts the features and output parameters
and stores them in test-query.csv. Please note that TeradataPy.py removes this
CSV file on every user input loop.

5. training-set/ : This folder contains the training set queries we used from
the TPC-H benchmark. They need the underlying dataset to operate so make sure
that is part of your database before attempting to utilize these queries.

6. test-set/ : This folder contains the test set queries we used from TPC-H.

*******************************************************************************
** TPC-H Benchmark
*******************************************************************************
We used the TPC-H benchmark (http://www.tpc.org/tpch/) to analyze TeradataPy.
Populating the database and generating executable SQL from the templates is
made easy through the How-to guide provided in the ./dbgen folder of the 
download. We used a scale factor of 1 GB and we removed query 1 and query 11
since they had compilation issues. There are no implementation details of 
TeradataPy that are coupled with the TPC-H benchmark in particular, and it 
should be able to be used with any workload of sufficient size.

*******************************************************************************
** Usage Notes
*******************************************************************************
Please note that the TeradataPy tool must have access to BTEQ, which we have
access to since we ran our experiments using Teradata Express for VMWare 
Player. The program may not work if it is not placed on the database server
itself, although we have not attempted using BTEQ on the client side.
