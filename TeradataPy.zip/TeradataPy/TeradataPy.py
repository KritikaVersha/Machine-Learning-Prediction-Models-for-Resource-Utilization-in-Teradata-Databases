import TeradataML as td
import subprocess
import os

trainingscript = "process-training-set.sh"
testscript = "process-test-query.sh"
trainingresults = "dbqlog-dump.csv"
testresults = "test-query.csv"

if __name__ == '__main__':
	testing = False
	if testing:
		td.showPredictions(trainingresults, testresults)
		quit()
	server = raw_input('Enter your Teradata server IP: ')
	uname = raw_input('Enter your user name: ')
	pwd = raw_input('Enter your password: ')
	db = raw_input('Enter your database name: ')
	trainingdir = raw_input('Enter your training set directory: ')

	subprocess.call(["bash", trainingscript, server, uname, pwd, db, trainingdir])
	print "Ready to predict query resource utilization!\n"

	while True:
		query = raw_input('Enter a test query or QUIT: ')
		if query.strip() == 'QUIT':
			break
		subprocess.call(["bash", testscript, server, uname, pwd, db, query])
		print '\n'
		td.showPredictions(trainingresults, testresults)
		os.remove(testresults)

	os.remove(trainingresults)
	
