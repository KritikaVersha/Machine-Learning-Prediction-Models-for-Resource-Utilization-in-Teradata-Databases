#!/bin/bash

# Obtain all of the input arguments
server=$1
username=$2
password=$3
database=$4
testfile=$5

# Create the BTEQ script for running the query
outfile=out-${testfile}
echo .logon $server/$username,$password >> run-test-query.bteq
echo DATABASE $database\; >> run-test-query.bteq
echo BEGIN QUERY LOGGING WITH XMLPLAN ON dbc\; >> run-test-query.bteq
echo .RUN FILE=$testfile >> run-test-query.bteq
echo END QUERY LOGGING ON dbc\; >> run-test-query.bteq
echo .LOGOFF >> run-test-query.bteq
echo .QUIT >> run-test-query.bteq

# Run the script and populate the XMLPLAN
echo "Running the query to obtain input parameters..."
bteq < run-test-query.bteq > test-query.log 2> test-query-err.log

# Create the BTEQ script for extracting the XML data
echo .logon $server/$username,$password >> extract-xml.bteq
echo .SET WIDTH 60000 >> extract-xml.bteq
echo ".SET SEPARATOR '\",\"'" >> extract-xml.bteq
echo .EXPORT FILE=test-query.csv >> extract-xml.bteq
echo "SELECT 
L.queryid,
L.querytext,
L.numresultrows,
L.utilityrowcount,
L.callnestinglevel,
L.queryband,
L.starttime,
L.firststeptime,
L.firstresptime,
L.numsteps,
L.totaliocount,
L.ampcputime,
L.parsercputime,
L.utilitybytecount,
L.delaytime,
L.numofactiveamps,
L.maxampcputime,
L.maxcpuampnumber,
L.maxampio,
L.maxioampnumber,
L.minampio,
L.spoolusage,
L.responsetimemet,
L.tdwmestmaxrows,
L.tdwmestlastrows,
L.tdwmesttotaltime,
L.ampcputimenorm,
L.parsercputimenorm,
L.maxampcputimenorm,
L.maxcpuampnumbernorm,
L.minampcputimenorm,
L.estproctime,
L.estmaxrowcount,
L.wddelaytime,
L.parserexpreq,
L.cpudecaylevel,
L.iodecaylevel,
L.seqresptime,
L.reqiokb,
L.reqphysio,
L.reqphysiokb,
X.XMLTextInfo 
FROM (SELECT TOP 1 * FROM dbqlogtbl ORDER BY starttime DESC) as L INNER JOIN dbqlxmltbl as X
ON L.queryid = X.queryid;" >> extract-xml.bteq
echo .EXPORT RESET >> extract-xml.bteq
echo .LOGOFF >> extract-xml.bteq
echo .QUIT >> extract-xml.bteq

# Run the script to extract the XML
echo "Extracting the XML data..."
bteq < extract-xml.bteq > test-query.log 2> test-query-err.log

# Format the output for proper parsing
sed -i -e "s/[[:space:]]\+/ /g" test-query.csv
sed -i -e 's/$/"/' test-query.csv
sed -i -e 's/^/"/' test-query.csv
sed -i '2d' test-query.csv

# Clean up the directory
rm run-test-query.bteq
rm extract-xml.bteq
rm test-query.log
rm test-query-err.log
