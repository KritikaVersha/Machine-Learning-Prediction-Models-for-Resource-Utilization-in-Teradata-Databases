#!/bin/bash

# Obtain the input arguments
server=$1
username=$2
password=$3
database=$4
training_dir=$5

# Push the passed in login parameters to the BTEQ script
echo .logon $server/$username,$password >> run-queries.bteq

# Access the specified database
echo DATABASE $database\; >> run-queries.bteq

# Invoke logging into dbqlogtbl and dbqlxmltbl
echo BEGIN QUERY LOGGING WITH XMLPLAN ON dbc\; >> run-queries.bteq

# Run all of the queries
for f in $training_dir/*.sql; do
	echo .RUN FILE=$f\; >> run-queries.bteq
done

# Finish generating the BTEQ script
echo END QUERY LOGGING ON dbc\; >> run-queries.bteq
echo .LOGOFF >> run-queries.bteq
echo .QUIT >> run-queries.bteq

# Run the BTEQ script to populate the log tables
echo "Running training set..."
bteq < run-queries.bteq > run-training-set.log 2> run-training-set-err.log

# Push the passed in login parameter to the extraction script
echo .logon $server/$username,$password >> grab-logtbl.bteq

# Export the output to the specified file
echo .EXPORT FILE=dbqlog-dump.csv >> grab-logtbl.bteq

# Set formatting options for the output file
echo .SET WIDTH 60000 >> grab-logtbl.bteq
echo ".SET SEPARATOR '\",\"'" >> grab-logtbl.bteq

# Get the number of training set queries
numqueries=`ls -f $training_dir | wc -l`
numqueries=$((numqueries - 2))

# Run the query to extract features from the log tables
echo "SELECT
L.queryid,
L.querytext,
L.numresultrows,
L.utilityrowcount,
L.callnestinglevel,
L.queryband,
L.starttime,
L.firststeptime,
L.firstresptime,
L.numsteps,
L.totaliocount,
L.ampcputime,
L.parsercputime,
L.utilitybytecount,
L.delaytime,
L.numofactiveamps,
L.maxampcputime,
L.maxcpuampnumber,
L.maxampio,
L.maxioampnumber,
L.minampio,
L.spoolusage,
L.responsetimemet,
L.tdwmestmaxrows,
L.tdwmestlastrows,
L.tdwmesttotaltime,
L.ampcputimenorm,
L.parsercputimenorm,
L.maxampcputimenorm,
L.maxcpuampnumbernorm,
L.minampcputimenorm,
L.estproctime,
L.estmaxrowcount,
L.wddelaytime,
L.parserexpreq,
L.cpudecaylevel,
L.iodecaylevel,
L.seqresptime,
L.reqiokb,
L.reqphysio,
L.reqphysiokb,
X.XMLTextInfo
FROM (	SELECT TOP $numqueries * 
	FROM dbqlogtbl
	ORDER BY starttime DESC) as L INNER JOIN dbqlxmltbl as X
ON L.queryid = X.queryid
ORDER BY L.queryid;" >> grab-logtbl.bteq

# Finish generating the extraction script
echo .EXPORT RESET >> grab-logtbl.bteq
echo .LOGOFF >> grab-logtbl.bteq
echo .QUIT >> grab-logtbl.bteq

# Run the extraction script
echo "Extracting log data..."
bteq < grab-logtbl.bteq > run-training-set.log 2> run-training-set-err.log

# Format the output for proper parsing
sed -i -e "s/[[:space:]]\+/ /g" dbqlog-dump.csv
sed -i -e 's/$/"/' dbqlog-dump.csv
sed -i -e 's/^/"/' dbqlog-dump.csv
sed -i '2d' dbqlog-dump.csv

# Clean up the directory
rm run-queries.bteq
rm grab-logtbl.bteq
rm run-training-set.log
rm run-training-set-err.log
